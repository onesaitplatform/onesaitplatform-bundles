var FrontendController = function() {
    
	// DEFAULT PARAMETERS, VAR, CONSTS. 
    var APPNAME = 'onesait Platform Frontend'; 
	var LIB_TITLE = 'Frontend Configuration Controller';	
    var logControl = 1;
	var LANGUAGE = ['en'];
	var currentLanguage = ''; // loaded from template.
	var currentYear = new Date().getFullYear();
	var host = window.location.host || 'https://development.onesaitplatform.com/'; 
	
	// DYN. DEPENDECIES
	var scripts  = [];
	var cssFiles = [];
	
	// CONTROLLER PRIVATE FUNCTIONS ---------------------------------------------------------
	
	var getUrlAuthentication = function(){
		if(window.securityMode === 'openid'){
			return frontReg.access.urlBase + '/auth/realms/onesaitplatform/protocol/openid-connect/token';
		}else{
			return frontReg.access.urlBase + '/oauth-server/oauth/token'
		}
	}
	// Login using oauth Server 
	var doLogin = function(){
		
		let username 	  = $("input#username").val() || '';
		let password 	  = $("input#password").val() || '';		
		let accessToken   = '';
		let loggedUser	  = '';
		let loggedEmail	  = '';
		var roles		  = '';
		var emailDomain   = '@minsait.com';
		
		if (!username || !password) { $.alert({title: 'Login:', icon:'la la-warning', theme:'light', type:'red', content: 'Fill login and password!'}); return false; }
		
		// API TOKEN		
		apiToken = "8f1fdc5ab7c64f75a1aea40ce401a7c6"; // NEEDS TOKEN to load Configuration Users Menu and conf.
		
		// api endpoint
		var url_login = frontReg.access.urlBase + '/oauth-server/oauth/token';
		var url_login_openid = frontReg.access.urlBase + '/auth/realms/onesaitplatform/protocol/openid-connect/token';
		
		// api roles endpoint check entities (ROLES EXTENSION, disabled)
		var url_roles = frontReg.access.urlBase + '/imextension/api/v1.0/users/roles';
		
		// REALM CONTROL
		if (frontReg.access.realm) {
			var realmKey = frontReg.access.realmConf.secret ? frontReg.access.realmConf.secret : frontReg.access.realmConf.realmId;
			var realmId  = frontReg.access.realmConf.realmId;
			var clientId = frontReg.access.realmConf.clientId ? frontReg.access.realmConf.clientId : frontReg.access.realmConf.realmId;
			var auth_token = '' + realmId + ':' + realmKey;
			auth_token = window.btoa(auth_token);
			
			// json data
			var requestPayload = {'grant_type' : 'password', 'username' : username, 'password' : password ,'scope': 'openid', 'client_id': clientId};
		} 
		else {
			
			// auth_token base64
			var auth_token = 'onesaitplatform:onesaitplatform';
			auth_token = window.btoa(auth_token);
			
			// json data
			var requestPayload = {'grant_type' : 'password', 'username' : username, 'password' : password };			
		}
				
		// api call
		$.ajax({'url': getUrlAuthentication(), 'type':'POST', 'content-Type': 'x-www-form-urlencoded',
			'headers': {'Authorization' : 'Basic ' + auth_token },
			'data' : requestPayload,

			'success': function(result) {			
				accessToken = result.access_token;			
				saveSession(accessToken);
				if ( frontReg.header.headerRoles ){ roles = getRoles(accessToken,url_roles) }
			},
			'error' : function(req, status, err) {
					$.alert({title: 'Login error:' + err, icon:'la la-warning', theme:'light', type:'red', content: 'Something went wrong on login: ' + req.responseText});
					return false
			},
			'complete': function(){
				
				// if project set project for favorites search
				if (frontReg.access.project){ sessionStorage.setItem("project",frontReg.access.project); }
				
				$.ajax({
					type : "GET",					
					url: frontReg.access.urlBase + "/controlpanel/api/users/" + $("input#username").val(),
					dataType : 'json',
					contentType : 'application/json',															
					headers : {
						"Authorization": 'Bearer ' + accessToken						
					},				
					success : function(response) {						
						if (response){			
							var extraFields = response.hasOwnProperty(extraFields) ? JSON.parse(response.extraFields) : '';
							loggedUser	= response.username || '';
							loggedEmail	= response.mail || '';
							if ( loggedUser && loggedEmail ){ sessionStorage.setItem('user',loggedUser); sessionStorage.setItem('email', loggedEmail); }								
						}					
					},
					error : function(req, status, err) {
						console.log('Something went wrong getting user extended Info.',req.responseText, status, err);						
					},
					complete: function(){
						
						// load frontend configuration by user from API.
						if ( apiToken ){
							$.ajax({
								type: "GET",					
								url: frontReg.access.urlApi + "/v1/TemplateWebConfiguration/TemplateConfigurationByUser/" + $("input#username").val(),
								dataType: 'json',
								contentType: 'application/json',															
								headers : {
									"X-OP-APIKey": apiToken,              	
									"Content-Type":"application/json",
									"Accept": "application/json"              	
								},						
								success: function(response) {						
									if ( response.length > 0 ){		
										logControl ? console.log('doLogin() -> Frontend configuration by user...') : '';
										var menuJson = response[0].TemplateWebConfig.menuJson || '';
										var mainJson = response[0].TemplateWebConfig.mainJson || '';
										if ( menuJson && mainJson ){ sessionStorage.setItem('userMenu',menuJson); sessionStorage.setItem('userConfiguration', mainJson); }																		
									}					
								},
								error: function(req, status, err) {
									console.log('Something went wrong getting user frontend configuration Info.',req.responseText, status, err);						
								},
								complete: function(){
									
									// no email info, default.
									if ( !loggedUser && !loggedEmail) {
										sessionStorage.setItem('user',username); sessionStorage.setItem('email', username + emailDomain);
									}
									
									// REAL ROLE FOR USER
									//sessionStorage.setItem("ENTITY_ROL", roles.defaultEntity);								
									console.log('login completed...');
									
									if ( frontReg.header.headerRoles ){ sessionStorage.setItem('DASHBOARDS_ROLES',JSON.stringify(roles)); }
									location.href = frontReg.access.urlBasePath + "index.html"; // go to index.
								}
							})
						}
						else{
							// default load index
							if ( frontReg.header.headerRoles ){ sessionStorage.setItem('DASHBOARDS_ROLES',JSON.stringify(roles)); }								
							location.href = frontReg.access.urlBasePath + "index.html"; // go to index.
						}
					}
				})				
			}
		})		
	}
	
	
	// get user Roles and entities
	var getRoles = function(accessToken, endPoint){	
	
		var role = {"defaultEntity": '', "defaultRole": '', "defaultRoleName": '', "roleSelector": []};
				
		$.ajax({type : "GET", url: endPoint , dataType : 'json', contentType : 'application/json', 
			headers : {
				"Authorization": 'Bearer ' + accessToken						
			},				
			success : function(response) {						
				if (response){			
					console.log('RESPONSE FROM ROLES... ' + JSON.stringify(response));
					if (response.entities){
						
						// infoEntity primero las report > 0 y default si no hay default, la primera encontrada con report > 0.
						var infoEntity = response.entities.find( x => (x.defaultEntity === true)&&( x.report > 0 ) ) || response.entities.find( x => x.report > 0 ) || '';
						
						// entity
						var defaultEntity = infoEntity ? infoEntity.idEntity : '';
						
						// Role
						var defaultRole = infoEntity ? infoEntity.idRol : '';
						
						// Role name
						var defaultRoleName = infoEntity ? infoEntity.profile.nameProfile : ''; 
						
						if ( defaultEntity && defaultRole  ) {
							
							role.defaultEntity   = defaultEntity;
							role.defaultRole	 = defaultRole;
							role.defaultRoleName = defaultRoleName;
						}
						
						// mount role selector
						// idRol-idEntity-nameProfile
						var roleSelector = [];
						var roleOption = '';
						var entities = response.entities;
						var nameProfile = '';
						entities.forEach(function(item){
							nameProfile = '';
							nameProfile = item.profile.nameProfile;
							nameProfile = nameProfile.replace(/(\r\n|\n|\r)/gm, "");
							
							// only roles with report > 0
							if ( item.report > 0 ){
								roleSelector.push('' + item.idEntity + '-' + item.idRol + '-' + nameProfile);
							}
						});
						
						role.roleSelector = roleSelector;
					}
				}					
			},
			error : function(req, status, err) {
				console.log('Something went wrong getting user extended Role and Entities Info.',req.responseText, status, err);				
			}
			
		});

		return role;				
	}
	
	// get selected role, and change the role for dashboads.
	var changeRole = function(obj){
		logControl ? console.log('|---> changeRole() -> change user role on current session data for dashboards.') : '';
		
		var entityId = $(obj).attr("data-entity") || '';
		var roleId   = $(obj).attr("data-role") || '';
		var roleName = $(obj).attr("data-roleName") || 'Default';
		var currentDashboard = sessionStorage.getItem("currentDashboard") || '';
		
		logControl ? console.log('|---> changeRole() -> entity: ' + entityId + ' role: ' + roleId + ' name: ' + roleName + ' current dashboard: ' + currentDashboard ) : '';
		
		if (entityId && roleId){
			
			// change selection on roleSelector
			$('#activeRole').text(roleName);
			
			// remove las active, and set new active role
			$('div#availableRoles').find('button').removeClass('active');
			$("div#availableRoles button[data-role='"+ roleId +"']").addClass('active');
			
			// change entity and role on current session.
			sessionStorage.setItem("ROL", roleName);
			sessionStorage.setItem("ENTITY_ROL", entityId);
			
			// reload currentDashboard to get the new role configuration
			if ( currentDashboard ) {
				
				// reload current dashboard.
				getDashboard(currentDashboard, 'DASHBOARD', '', '', 'INSERT');
			}
			else {
				// no current dashboard, reload index.
				location.href = frontReg.access.urlBasePath + "index.html";				
			}			
		}
		else {
			$.alert({title: 'Role Configuration Error:', icon:'la la-warning', theme:'light', type:'red', content: 'Something went wrong on role configuration'});			
		}		
	}
	
	
	// create role selector on header 
	var createRoleSelector = function(){
		
		var sessionInfoRoles = {};
		var roleOptions		 = [];
		var defaultFound	 = false;
	
		logControl ? console.log('|---> createRoleSelector() -> creating user role selector on header.') : '';		
		
		// check for role configuration on session or get from service
		var sessionInfo = sessionStorage.getItem("DASHBOARDS_ROLES") || '';
		if ( sessionInfo ){			
			sessionInfoRoles = JSON.parse(sessionInfo);			
		}
		else {
			let auth = getAuthorization();
			sessionInfoRoles = getRoles( auth , url_roles);			
		}
		
		// create elements on selector. ["1-24-Responsable proyecto",...
		var selObj = $('#availableRoles');
		var optionbutton = '';
		var activeClass  = '';
		var foundCoordinator = false; // idEntity 0 is coordinator.
		var joinRoles 	 = [];
		roleOptions = sessionInfoRoles.roleSelector;
		for ( let i = 0; i < roleOptions.length; i++ ){			
			optionbutton = '';
			if ( sessionInfoRoles.defaultRole == roleOptions[i].split("-")[1] ){ activeClass = 'active'; defaultFound = true; } else { activeClass = '' }
			
			optionbutton = '<button class="dropdown-item '+ activeClass +'" type="button" data-entity="'+ roleOptions[i].split("-")[0] +'" data-role="'+ roleOptions[i].split("-")[1] +'" data-roleName="'+ roleOptions[i].split("-")[2] +'" onclick="FrontendController.roleConfiguration(this)">'+ roleOptions[i].split("-")[2] +'</button>';
			selObj.append( optionbutton );
			
			if ( roleOptions[i].split("-")[0] == 0 ){ foundCoordinator = true; }
			
			// mount a join mix dynamic role
			jQuery.inArray( parseInt(roleOptions[i].split("-")[0]), joinRoles ) === -1 ? joinRoles.push(parseInt(roleOptions[i].split("-")[0])) : '';			
		}
		
		// if not coordinator found, mount dynamical join role
		if (!foundCoordinator){
			selObj.append( '<button class="dropdown-item" type="button" data-entity="['+ joinRoles.toString() +']" data-role="0" data-roleName="Rol Conjunto" onclick="FrontendController.roleConfiguration(this)">Rol Conjunto</button>' );
		}
		
		// set default role for user
		$('#activeRole').text(sessionInfoRoles.defaultRoleName); 
		
		if (roleOptions.length == 0 ){ 
			$('#activeRole').text('Sin ROLES');
			// valor especial sin ROles, bloquea los informes.
			sessionStorage.setItem("ENTITY_ROL", -1); 
		}
		
	}

		
	// get Current Page loaded
	var getCurrentPage = function(){
		let templ = top.location.pathname ? top.location.pathname : window.location.pathname;
		let page  = templ.split("/").pop();		
		return page;		
	}
	
	
	// store user data in session
	var saveSession = function(accessToken){
		sessionStorage.setItem('accessToken', accessToken);				
	}	
	
	
	// clear session and go to Login.
	var closeSession = function(){
		sessionStorage.clear();
		window.location.href = frontReg.access.urlBasePath + "login.html";				
	}
	
	
	// check if the user data are stored in session if not, closeSession.
	var hasSession = function(access){		
		
		var page = getCurrentPage();		
		if ( page === 'login.html'){ return false; }		
		if ( access === 'PRIVATE'){
			if( sessionStorage.getItem("accessToken") ){
				$('.loading').fadeOut('slow');
				// to-do: session conf.
			}
			else {
				$('.loading').fadeIn('slow');
				closeSession(); 
			}
		} else { $('.loading').fadeOut('slow'); return true; }
	}
	
	
	// Get API authorization
	var getAuthorization = function(){		
		return sessionStorage.getItem('accessToken') || '';		
	}
	
	
	// loadDependecies, Load dynamically JS and CSS files for headerlibs only if VUEJS WRAPPER is enabled.
	var loadDependecies = function(configuration){
		
		logControl ? console.log('|---> loadDependecies() -> Loading dynamical dependencies por Dashboards, VUE WRAPPER Mode:') : '';
		
		// no configuration, no fun!
		if (!configuration){ $.alert({title: 'Configuration ERROR!',content: 'No Configuration Data!'}); return false; }
		
		if (configuration.app.hasOwnProperty('appHeaderLibs')){
			
			headerLibs	= configuration.app.appHeaderLibs;
			scripts		= headerLibs.js;
			cssFiles	= headerLibs.css;
			
			// LOAD CSS files
			if (cssFiles.length > 0){
				
				var isLoaded = function(css){		
					var links = document.getElementsByTagName('link'),
					loaded = true;
					for ( var i = 0; i < links.length; i++ ){ if ( links[i].href == css ) loaded = false; break; }		
					return loaded;
				};
				
				var loadCascadeStyleSheet = function(css){
					if (css.loaded && isLoaded(css.src)){ 
						logControl ? console.log('|---> loadDependecies() -> Loading CSS: ' + css.src + ' is Already Loaded') : '';
						return false;
					}
					if (document.createStyleSheet){
						document.createStyleSheet(css.src);
						css.loaded = true;						
					}
					else {
						$("head").append($("<link rel='stylesheet' href='"+ css.src +"' type='text/css' media='screen' />"));
						css.loaded = true;
					}
					
					logControl ? console.log('|---> loadDependecies() -> Loading CSS: ' + css.src + ' Loaded') : '';
				};
				
				cssFiles.forEach((css) => loadCascadeStyleSheet(css));
				
			} else { logControl ? console.log('|---> loadDependecies() -> NO CSS Dependencies.') : ''; }
			
			// LOAD JS files
			if (scripts.length > 0){
				
				var loadScript = function(name) {	
					return new Promise((resolve, reject) => {
					
						// resolve if already loaded
						var scrObj = scripts.filter(x => x.name === name)[0];
						if (scrObj.loaded) {
							logControl ? console.log('|---> loadDependecies() -> Loading JS: ' + name + ' is Already Loaded') : '';
							resolve({ script: name, loaded: true, status: 'Already Loaded' });
						} else {
							// load script
							const script = document.createElement('script');
							script.type = 'text/javascript';
							script.src = scrObj.src;
							script.onload = () => {
								scrObj.loaded = true;
								logControl ? console.log('|---> loadDependecies() -> Loading JS: ' + name + ' Loaded') : '';
								resolve(scrObj.loaded = true);
							};
							script.onerror = (error) => resolve({ script: name, loaded: false, status: 'Loaded' });
							document.getElementsByTagName('head')[0].appendChild(script);
						}
					});
				};
				
				// Load JS on Promises
				const promises = [];
				scripts.forEach((script) => promises.push(loadScript(script.name)));
				Promise.all(promises).then(function(){
					
					// all dependecies are loaded, then load the initial dashboard.
					let dashboard = configuration.content.contentDashboard;			
					getDashboard(dashboard.src, dashboard.dashboardName, dashboard.background, dashboard.height, dashboard.mode);
					
				});
				
				
			} else { logControl ? console.log('|---> loadDependecies() -> NO JS Dependencies.') : ''; }
		}		
	}
	
	
	// Configure all elements from page: Access, info, header, initial content, footer,...
	var handleConfiguration = function(configuration){			
			
		logControl ? console.log('|---> handleConfiguration() -> Configuration of Frontend.') : '';
		
		// no configuration, no fun!
		if (!configuration){ $.alert({title: 'Configuration ERROR!',content: 'No Configuration Data!'}); return false; }
		
		// loading image conf.
		configuration.app.appLoading !== '' ? $('#app-loading').attr('src',configuration.app.appLoading) : '';

		// check Access in session
		hasSession(configuration.access.entry);
		
		// change configuration for user configuration on the fly
		var userConfiguration = sessionStorage.getItem("userConfiguration");
		if ( userConfiguration !== null ) {  configuration = JSON.parse(sessionStorage.getItem("userConfiguration")); console.log('App Configuration updated on the fly'); }
		
		
		// page settings after checkAccess
		document.title = configuration.title || 'FRONTEND';
		document.head.querySelector("[name='description']").content = configuration.description || 'FRONTEND Description';
		$('#app-home').text(configuration.app.appHome || 'FRONTEND');
		$('#content-title').text(configuration.content.contentTitle || 'FRONTEND BASE CARD');
		if ( configuration.app.appLogo != ''){
			$('#app-logo').attr('src',configuration.app.appLogo);
			configuration.app.appLogoCss ? $('#app-logo').attr('style',configuration.app.appLogoCss) : '';
			configuration.app.appLogoBackground ? $('.m-brand__logo').attr('style',configuration.app.appLogoBackground) : '';
		}
		
		if ( configuration.app.appSecondaryLogo !== ''){
			$('#app-secondaryLogo-nav').removeClass('m--hide');
			$('#app-secondaryLogo').attr('src',configuration.app.appSecondaryLogo);
			configuration.app.appSecondaryLogoCss ? $('#app-secondaryLogo').attr('style',configuration.app.appSecondaryLogoCss) : '';			
		}
		
		// check exception login page
		var page = getCurrentPage();
		if ( page === 'login.html'){ handleLogin(configuration); return false; }

		// if VUE WRAPPER is enabled and need dependecies, then load.
		if (frontReg.app.appDashboardsVue){ loadDependecies(configuration); }
			
		// element visualization after check exception
		let header = configuration.header;
		configuration.app.appFooter			    ? $('#app-footer').removeClass('m--hide')			: $('#app-footer').addClass('m--hide');
		configuration.app.appStickymenu == true ? $('#app-stickymenu').removeClass('m--hide')		: $('#app-stickymenu').addClass('m--hide');
		if (configuration.app.appStickymenu == true ){
			$('#app-stickymenu_doc').attr('href',configuration.app.appStickymenuRef.documentation || '#');
			$('#app-stickymenu_sup').attr('href',configuration.app.appStickymenuRef.support || '#');
		}
		header.headerDashboads	 			 ? $('#header-dashboards').removeClass('m--hide')		: $('#header-dashboards').addClass('m--hide');
		header.headerReports				 ? $('#header-reports').removeClass('m--hide')			: $('#header-reports').addClass('m--hide');
		header.headerSearch					 ? $('#m_quicksearch').removeClass('m--hide')			: $('#m_quicksearch').addClass('m--hide');
		header.headerNotifications 			 ? $('#header-notifications').removeClass('m--hide') 	: $('#header-notifications').addClass('m--hide');
		header.headerQuickactions			 ? $('#header-quickactions').removeClass('m--hide')		: $('#header-quickactions').addClass('m--hide');
		header.headerUser					 ? $('#header-user').removeClass('m--hide')				: $('#header-user').addClass('m--hide');
		header.headerRoles					 ? $('#header-entityRoles').removeClass('m--hide')		: $('#header-entityRoles').addClass('m--hide');	
		header.headerSessionConfiguration	 ? $('#header-configuration').removeClass('m--hide')	: $('#header-configuration').addClass('m--hide');
		header.headerSidebarToggle 			 ? $('#m_quick_sidebar_toggle').removeClass('m--hide')	: $('#m_quick_sidebar_toggle').addClass('m--hide');
		
		
		// if userRoles then create roleSelector
		if ( header.headerRoles ){ createRoleSelector(); }
		
		if ( configuration.content.contentHead) {
			$('#content-head').removeClass('m--hide');
			configuration.content.contentHeadCss !== '' ? $('#content-head').attr('style', configuration.content.contentHeadCss ) : '';
			configuration.content.contentTitleCss !== '' ? $('h3.m-portlet__head-text').attr('style', configuration.content.contentTitleCss) : '';
			$('#content-head-title').removeClass('m--hide');
		}
		else {
			$('#content-head').addClass('m--hide');	
		}
		configuration.content.contentTools ? $('#content-tools').removeClass('m--hide') : $('#content-tools').addClass('m--hide');
		
		// favorites toolBar
		if (configuration.content.contentFavorites){
			configuration.content.favorites.toggle ? $('#favorites-item').removeClass('m--hide') : $('#favorites-item').addClass('m--hide');
			configuration.content.favorites.reload ? $('#favorites-item-reload').removeClass('m--hide') : $('#favorites-item-reload').addClass('m--hide');
			
		} else { $('#favorites-item, #favorites-item-reload').addClass('m--hide') }
		
		// external filters toolBar		
		configuration.content.contentFilters ? $('#filters-item').removeClass('m--hide') : $('#filters-item').addClass('m--hide');	

		// save dashboard btn			
		configuration.content.contentSave == true ? $('#save-item').removeClass('m--hide') : $('#save-item').addClass('m--hide');			
				
		// loading initial Dashboard on Iframe mode
		if ( configuration.content.contentDashboard.enabled && frontReg.app.appDashboardsVue == false){
			let dashboard = configuration.content.contentDashboard;			
			getDashboard(dashboard.src, dashboard.dashboardName, dashboard.background, dashboard.height, dashboard.mode);
		}		
		
		// wellcome msg
		configuration.app.appWelcome ? toastr.info('Wellcome to ' + configuration.app.appHome + ' :)', configuration.app.appHome +':') : '';		
		
		// user Elements
		if ( configuration.header.headerUser ){	
		
			configuration.user.showAvatar ? configuration.user.avatar ? $('.m-card-user__pic').find('img').attr('src',configuration.user.avatar) : $('.m-card-user').removeClass('m--hide') : $('.m-card-user').addClass('m--hide');
		
			// Profile
			let profile = configuration.user.profile;
			profile.visible == true ? $('#user-profile').removeClass('m--hide').find('a.m-nav__link').attr('href',profile.link).find('span.m-nav__link-text').text(profile.text) : $('#user-profile').addClass('m--hide');
			
			// support
			let support = configuration.user.support;
			support.visible == true ? $('#user-support').removeClass('m--hide').find('a.m-nav__link').attr('href',support.link).find('span.m-nav__link-text').text(support.text) : $('#user-support').addClass('m--hide');
			
			// Activity
			let activity = configuration.user.activity;
			activity.visible == true ? $('#user-activity').removeClass('m--hide').find('a.m-nav__link').attr('href',activity.link).find('span.m-nav__link-text').text(activity.text) : $('#user-activity').addClass('m--hide');
			
			// messages
			let messages = configuration.user.messages;
			messages.visible == true ? $('#user-messages').removeClass('m--hide').find('a.m-nav__link').attr('href',messages.link).find('span.m-nav__link-text').text(messages.text) : $('#user-messages').addClass('m--hide');
			
			// faq			
			let faq = configuration.user.faq;
			faq.visible == true ? $('#user-faq').removeClass('m--hide').find('a.m-nav__link').attr('href',faq.link).find('span.m-nav__link-text').text(faq.text) : $('#user-faq').addClass('m--hide');						
			
			// logout
			let logout = configuration.user.logout;
			logout.visible == true ? $('#user-logout').find('a.btn').text(logout.text) : $('#user-logout').addClass('m--hide');
			
			//user and email 			
			if (sessionStorage.getItem('user') && sessionStorage.getItem('email') ){
				$('.m-card-user__name').text(sessionStorage.getItem('user'));
				$('.m-card-user__email').text(sessionStorage.getItem('email'));
			}
		}
		
		// footer links and elements
		if ( configuration.app.appFooter ){			
			$('#footer-copyright').html(configuration.footer.footerCopyright || currentYear + ' &copy; FRONTEND');
			if ( configuration.footer.footerLinks ){
				
				// About
				let about = configuration.footer.footerLinkAbout;
				about.visible == true ? $('#footer-link-about').find('a.m-nav__link').attr('href',about.link).find('span').text(about.text): $('#footer-link-about').addClass('m--hide');
				
				// privacy 
				let privacy = configuration.footer.footerLinkPrivacy;
				privacy.visible == true ? $('#footer-link-privacy').find('a.m-nav__link').attr('href',privacy.link).find('span').text(privacy.text): $('#footer-link-privacy').addClass('m--hide');
				
				// terms 
				let terms = configuration.footer.footerLinkTerms;
				terms.visible == true ? $('#footer-link-terms').find('a.m-nav__link').attr('href',terms.link).find('span').text(terms.text): $('#footer-link-terms').addClass('m--hide');
				
				// company 
				let company = configuration.footer.footerLinkCompany;
				company.visible == true ? $('#footer-link-company').find('a.m-nav__link').attr('href',company.link).find('span').text(company.text): $('#footer-link-company').addClass('m--hide');
				
				// support
				let support = configuration.footer.footerLinkSupport;
				support.visible == true ? $('#footer-link-support').find('a.m-nav__link').attr('title',support.text).attr('data-original-title',support.text) : $('#footer-link-support').addClass('m--hide');
			}
			
		}
		// themes and styling		
		let themes = configuration.themes;
		themes.changeSkin 			!== ''	? changeTheme(configuration.currentSkin, themes.changeSkin): '';
		themes.contentPadding		!== ''	? $('#app-content').attr('style','height: calc(100%);  padding: '+ themes.contentPadding + ';') : $('#app-content').attr('style','height: calc(100%); padding: 30px 30px;');
		themes.contentBackground	!== ''	? $('#app-content').css('background-color', themes.contentBackground ) : '';
		themes.footerBackground		!== ''	? $('#app-footer').css('background-color', themes.footerBackground ) : '';
		themes.menu 				!== ''	? changeMenu(configuration.currentSkin, themes.menu) : '';
		
		// creating session configuration clone on string.
		sessionStorage.setItem('configuration',JSON.stringify(configuration));
						
	}	
	
	
	// Configure all elements in Login page: Access, info, header, initial content
	var handleLogin = function(configuration){
		
		let username = $("#username").val() || '';
		let password = $("#password").val() || '';
		
		logControl ? console.log('|---> handleLogin() -> Login Configuration.') : '';
		
		// no configuration, no fun!
		if (!configuration){ $.alert({title: 'Configuration ERROR!',content: 'No Configuration Data!'}); return false; }
		
		// conf Public or Private Mode
		if ( configuration.access.entry === 'PUBLIC'){			
			$('#m_login_visit').removeClass('m--hide');
			$('#agreeTerms').removeClass('m--hide');
			$('#m_login_signup').addClass('m--hide');
			$('.m-login__border,.m-login__wrapper-2').addClass('m--hide');			
		}
		else {
			// PRIVATE
			$('#m_login_visit').addClass('m--hide');
			$('#m_login_signup').removeClass('m--hide');
			$('.m-login__border,.m-login__wrapper-2').removeClass('m--hide');
		}		
		
		// conf. texts, image, background and texts
		configuration.login.loginLogo ? $('#login-logo').attr('src',configuration.login.loginLogo).attr('style',configuration.login.loginLogoStyle) : '';
		configuration.login.loginDescription ? $('#login-description').text(configuration.login.loginDescription) : '';
		configuration.login.signInTitle ? $('#signin-title').text(configuration.login.signInTitle) : '';
		configuration.login.signInBtnColor !== '' ? $('#m_login_signin_submit').addClass(configuration.login.signInBtnColor) : $('#m_login_signin_submit').addClass('btn-primary');
		configuration.login.loginBackground ? $('#m_login').attr('style','background: url('+ configuration.login.loginBackground +') no-repeat; background-position: center; background-size: cover;') : '';
		
		// remember me , signUp, forgot Passwords forms only on private mode.
		if ( configuration.access.entry === 'PRIVATE'){
			if ( configuration.login.signUp ){
				$('.m-login__signup').removeClass('m--hide');
				$('#m_login_signup').removeClass('m--hide');
			}
			else{
				$('.m-login__signup').addClass('m--hide');
				$('#m_login_signup').addClass('m--hide');
			}		
			if ( configuration.login.forgotPassword ){
				$('.m-login__forget-password').removeClass('m--hide')
				$('#forget-password').removeClass('m--hide');
			}
			else{
				$('.m-login__forget-password').addClass('m--hide');
				$('#forget-password').addClass('m--hide');
			}
			configuration.login.rememberMe ? $('#remember-me').removeClass('m--hide') : $('#remember-me').addClass('m--hide');
		}else{
			// PUBLIC; add terms and conditions if are defined.
			if ( configuration.login.privacyLink )	 { $('#privacyLink').attr('href',configuration.login.privacyLink); }
			if ( configuration.login.conditionsLink ){ $('#conditionsLink').attr('href',configuration.login.conditionsLink); }
			
		}
		
		// setting enter key to send form 		
		$('#formLogin input:not([type="submit"])').keydown(function(e) {
			
			logControl ? console.log('|---> keydown() -> Login') : '';			
			
			if (e.keyCode == 13) {				
				username = $("#username").val() || '';
				password = $("#password").val() || '';
				
				if (username !== '' && password !== ''){
					doLogin();
				}
				else { 
					e.preventDefault();
					return false; 
				}
			}
		});
			
	}
	
	
	// change Template Theme
	var changeTheme = function(currentSkin,newSkin){
	
		if ( newSkin === currentSkin ) { return false }
		if ( !isValidSkin(newSkin)) { newSkin = ''}
		
		// no skin, no fun!
		if ( !newSkin ){ $.alert({title: 'Configuration ERROR!',content: 'No Skin or not valid for Change Theme!'}); return; }
		
		// change all the elements in page to new skin.
				
	}
 
 
	// change menu theme light or dark one	
	var changeMenu = function(currentSkin, newSkin ){
		
		if ( newSkin === currentSkin ) { return false }
		if ( !isValidSkin(newSkin)) { newSkin = ''}
		
		// no skin, no fun!
		if ( !newSkin ){ $.alert({title: 'Configuration ERROR!',content: 'No Skin or not valid for Change Menu Theme!'}); return; }
		
		// change menu classes for new skin.		
		let elements = ['m-aside-left--','m-aside-menu--','m-aside-menu--submenu-'];
		let currentElement	= '';
		let newElement		=  '';
		$.each(elements,function(index){			
			currentElement	= elements[index] + currentSkin;
			newElement		= elements[index] + newSkin;
			$('body').find('.'+ currentElement).removeClass(currentElement).addClass(newElement);			
		})		
	}
	
	
	// check if skin to change is a valid defined skin on main json on availableSkins[]
	var isValidSkin = function(skin){
		let isValid = false;		
		let skins = frontReg.themes.availableSkin || [];		
		
		jQuery.inArray(skin, skins) < 0 ? isValid = false : isValid = true;		
		return isValid;
	}
	

	// loading base configuration for online session configuration
	var handleSessionConfiguration = function(){
		
		logControl ? console.log('|---> handleSessionConfiguration() -> Online Configuration of Frontend.') : '';
		
		let sessionConfiguration	= JSON.parse(sessionStorage.getItem('configuration'));
		let sessionValue 			= '';
				
		// no configuration, no fun!
		if (!sessionConfiguration){ $.alert({title: 'Online Configuration ERROR!',content: 'No Configuration Data on Session!'}); return false; }
		
			
		// load information into form
		var nodes = $('#configurationForm').find(".data-node").not('.bootstrap-select');
		$.each(nodes,function(){ 
			logControl ? console.log($(this).attr('data-node') + ': ' + eval('sessionConfiguration.' + $(this).attr('data-node'))) : '';
						
			// Special fields (selectpicker, radios, checks... ) if not, regular val:
			sessionValue = eval('sessionConfiguration.' + $(this).attr('data-node'));
			$(this).hasClass('m_selectpicker') === true ?
				$(this).selectpicker('val',sessionValue) : 
					$(this).hasClass('m_switch') === true ?
						$(this).prop('checked',sessionValue) :
							$(this).val(sessionValue);			
		});		
		
		// running menu data.
		MenuController.configMenu('application-config');
		
		// close dashboard card
		$('#list-portlet').addClass('m--hide'); 
		
		// show configuration card
		$('#configuration-portlet').removeClass('m--hide');	
	}
	
	
	// Update or Save current session configuration to allow user to see changes on visualization frontend.
	//	type:   update / save
	//	update: just update the configuration 
	// 	save:   update the configuration and create a access in header to open a modal copy clipboard item, the user can copy and paste that configuration 
	//          on the application-config.js to update the saved configuration.	
	var updateSessionConfiguration = function(type){
		
		let updatedConfiguration = JSON.parse(sessionStorage.getItem('configuration'));
		
		logControl ? console.log('|---> updateSessionConfiguration('+ type +') -> update or update and save configuration') : '';
		
		// no configuration to update or save, no fun!
		if (!updatedConfiguration){ $.alert({title: 'Online Configuration ERROR!',content: 'No Configuration Data on Session to '+ type +'!'}); return false; }
		
		// UPDATE OR SAVE MAKE AND UPDATE OF CONFIGURATION
		// load information into form
		var nodes = $('#configurationForm').find(".data-node").not('.bootstrap-select');
		$.each(nodes,function(){ 
			logControl ? console.log($(this).attr('data-node') + ': ' + eval('updatedConfiguration.' + $(this).attr('data-node'))) : '';
						
			theValue = $(this).hasClass('m_selectpicker') === true ?
							$(this).selectpicker('val') : 
								$(this).hasClass('m_switch') === true ?
									($(this).prop('checked') ? true : false) :
										$(this).val();	
			// ASSIGN NEW VALUE
			var nodeStr = 'updatedConfiguration.' + $(this).attr('data-node');
			typeof theValue === 'string' ? eval(nodeStr + ' = "' + theValue + '"') : eval(nodeStr + ' = ' + theValue);	
			logControl ? console.log( nodeStr + ': ' + eval(nodeStr)) : '';
			
		});		
		
		// keep menu because updateconfiguration will restore menu 
		let updatedMenu = JSON.parse(sessionStorage.getItem('menu'));
		
		// update configuration
		FrontendController.load(updatedConfiguration);
		FrontendController.init();
		
		// update menu after configuration
		MenuController.load(updatedMenu);
		MenuController.init();// TO-DO: Add flag to not load user configuration if exists.
		
		
		if (type === 'save'){
			// SAVE CONFIGURATION: add changes to a link with modal to allow user to copy&paste all the JSON configuration.
			
			var strMenu = 'var menuJson = ' + JSON.stringify(updatedMenu, undefined, 4) + ';';
			var strApp  = 'var mainJson = ' + JSON.stringify(updatedConfiguration, undefined, 4) + ';';
			
			// show modal and display pretty printed object in text area:
			$('#modalSaveConfiguration').modal('show');
			document.getElementById('configurationArea').innerHTML = strMenu + "\n\n" + strApp;			
			
			// to-do: save that configuration in an ontology on onesait.
		}		
		else if (type === 'restore'){
			// restore configuration
			FrontendController.load(mainJson);
			FrontendController.init();
		
			// restore menu after configuration
			MenuController.load(menuJson);
			MenuController.init();			
			MenuController.configMenu('session');
		}
	}
		
		
	// loading into form a menu item to configure it
	var handleSessionMenu = function(item,mode){		
		logControl ? console.log('|---> handleSessionMenu() -> Online Configuration of Menu Items, mode: ' + mode ) : '';
		logControl ? console.log('|---> handleSessionMenu() -> ITEM: ' + JSON.stringify(item)) : '';
		var data = {};
		var type = $('#newitem-type').val();
		let isDashboard = false;
		
		if (mode === 'insert'){
			if (  type === '' || type === 'submenu'){  
				$('#newitem-type').selectpicker('val', 'submenu');
				type = 'submenu';
				data = {title: '', url: ''};
				$('.linkitem.insert').removeClass('m--hide');
				$('.insert').not('.linkitem').addClass('m--hide');
			} 
			else if (type === 'dashboard'){
				isDashboard = true;
				data = {title: '', url: '', dashboard: {title: '', src: '', background: '', height: ''}};
				$('.dashboarditem.insert').removeClass('m--hide');
				$('.insert').not('.dashboarditem').addClass('m--hide');
			}
			else {
				data = {title: '', url: '', menu: '' };					
				$('.menuitem.insert').removeClass('m--hide');
				$('.insert').not('.menuitem').addClass('m--hide');				
			}			
			// show insert item btn.
			$('#insertItem-Btn').removeClass('m--hide');
			$('#insertItem-Btn').attr('data-title',data.title);
			$('#updateItem-Btn').addClass('m--hide');			
		}
		else{
			// mode update
			data = item.hasOwnProperty('data') === true && item.hasOwnProperty('data')  !== null ? item.data : '';
			if (!data){ $.alert({title: 'Menu Item:',content: 'Item not editable'}); return false; }
			isDashboard = data.hasOwnProperty('dashboard') === true? true : false;			
			// show update item btn.
			$('#updateItem-Btn').removeClass('m--hide');			
			$('#updateItem-Btn').attr('data-title',data.title); // to find node on menuJson 
			$('#insertItem-Btn').addClass('m--hide');
		}
		
		if (isDashboard){
			// DASHBOARD ITEM			
			//"title":"Private Dashboard 2","dashboard":{"src":"https://development.onesaitplatform.com/controlpanel/dashboards/viewiframe/2730c859-6a69-4b5c-af94-3eac4abd851d","title":"Dashboard Private Example 2","background":"","height":"850px","mode":"INSERT"}}
			$('#menu-edit-alert').addClass('m--hide');	
			$('#linkItem').addClass('m--hide');			
			$('#menuItem').addClass('m--hide');
			$('#dashboardItem').removeClass('m--hide');
			$('#updateItem-Btn').attr('data-mode','dashboard');
			$('#insertItem-Btn').attr('data-mode','dashboard');
			
			$('#dashboard-title').val(data.title);
			$('#dashboard-src').val(data.dashboard.src);	
			$('#dashboard-background').val(data.dashboard.background);	
			$('#dashboard-height').val(data.dashboard.height);	
		}
		else if(data.hasOwnProperty('menu')) {
			// MENU ITEM			
			$('#menu-edit-alert').addClass('m--hide');			
			$('#menuItem').removeClass('m--hide');
			$('#linkItem').addClass('m--hide');			
			$('#dashboardItem').addClass('m--hide');
			$('#updateItem-Btn').attr('data-mode','menu');
			$('#insertItem-Btn').attr('data-mode','menu');			
			
			$('#menuitem-title').val(data.title);
			
		}
		else{
			// SUBMENU LINK or LINK ITEM			
			$('#menu-edit-alert').addClass('m--hide');			
			$('#linkItem').removeClass('m--hide');
			$('#dashboardItem').addClass('m--hide');
			$('#menuItem').addClass('m--hide');
			$('#updateItem-Btn').attr('data-mode','submenu');
			$('#insertItem-Btn').attr('data-mode','submenu');
			
			$('#linkitem-title').val(data.title);
			$('#linkitem-url').val(data.url);	
				
		}
	}
		
	
	//  TOASTR NOTIFICATIONS OPTIONS
	toastr.options = {
		"closeButton": true,
		"debug": false,
		"newestOnTop": true,
		"progressBar": true,
		"positionClass": "toast-top-right",
		"preventDuplicates": true,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	
	// TOASTR NOTIFICATION  
	// type: INFO, SUCCESS, WARNING, ERROR, show different colors
	var notification = function( type , title, description ){
		
		let notificationType  = type || 'info';
		let notificationTitle = title ? title : 'Information:';
		let notificationDesc  = description ? description : '';
		var types = {
			'success':	'toastr.success(notificationDesc, notificationTitle)',
			'info':		'toastr.info(notificationDesc, notificationTitle)',
			'warning':	'toastr.warning(notificationDesc, notificationTitle)',
			'error':	'toastr.error(notificationDesc, notificationTitle)',
		};		
		showLog ? console.log('notification with type: ' + notificationType + ' title: ' + notificationTitle + ' and description: ' + notificationDesc) : '';		
		if (types[ notificationType ]) { eval(types[ notificationType ]);}	
	};
	
	
	// GET DASHBOARD AND LOAD ONTO PAGE
	var getDashboard = function(src, title, background, height, mode){
			
		
		let backgroundParam = background || '#FFF';
		let heightParam		= height || '1000px';
		let modeParam		= mode || 'INSERT';
		var authorization	= getAuthorization();
		let srcParam		= authorization ? src +'?oauthtoken=' + authorization : src;
		let dashboardName	= title || frontReg.content.contentDashboard.dashboardName || 'Onesait Dashboard';
		var role			= sessionStorage.getItem("ENTITY_ROL") || '';
				
		
		logControl ? console.log('|---> getDashboard() -> ' + srcParam + ' name: ' + dashboardName + ' role: ' + role) : '';
		
		// role control for loading dashboards, needs role and active role configuration enabled.
		if ((role < 0) && ( frontReg.header.headerRoles )) { 
			$.alert({title: 'ERROR:', icon:'la la-warning', theme:'light', type:'red', content: 'THIS USER IS NOT ALLOWED TO EXECUTE REPORTS, PLEASE CONTACT ADMIN.'});
			$('.lds-ellipsis').addClass('m--hide');
			$('#role-info-error').removeClass('m--hide');	
			return false;
		}		
		
		$('.lds-ellipsis').removeClass('m--hide');
		
		if (!src){ 
			$('.lds-ellipsis').addClass('m--hide');
			$('#loading-info-error').removeClass('m--hide');			
			return false; 
		}
		
		// ADJUST MENU ACTIVE
		$('.m-menu__item--active').removeClass('m-menu__item--active');		
		$("a[data-src='" + src + "']").parent().addClass('m-menu__item--active').siblings().removeClass('m-menu__item--open'); 
		
		// LOADING CONTROL: IFRAME OR VUE WRAPPER (depends on appDashboardsVue in app-config.)
		if (frontReg.app.appDashboardsVue){
			
			var dashboardId  = src.split("/").pop();
			
			// style for Dashboad Container
			$('#inst1').css({"padding": "0px", "margin": "0px", "height": heightParam, "background-color": backgroundParam});
			
			// dashboard Auth.
			vueapp.token = authorization;
			
			// hide loader
			$('.lds-ellipsis').addClass('m--hide');
						
			// load dashboard.
			vueapp.dashboard = dashboardId;
			vueapp.i 		 = 1; // flag to load dashboard
			sessionStorage.setItem("currentDashboard", dashboardId);
			if (frontReg.content.contentHead){ $('#content-title').text(dashboardName); }
			
		}
		else {
		
			// if dashboard is already loaded
			if ( $("#main-dashboard-iframe").attr('data-loaded') ){
				$('#main-dashboard-container').addClass('m--hide');
				$('.lds-ellipsis').removeClass('m--hide');			
			}
			
			// notification
			frontReg.content.contentDashboard.notification ? toastr.success('The Dashboard ' + dashboardName + ' is loading...', 'Info:') : '';
			
			// iframe name
			dashboardName ? $('#content-title').text(dashboardName) : '';
			
			// iframe config.		
			$("#main-dashboard-iframe").attr('src', srcParam).attr('height',heightParam).attr('data-loaded',1).css('background-color', backgroundParam);		
			!$('#loading-info-error').hasClass('m--hide') ? $('#loading-info-error').addClass('m--hide') : '';
					
			// get menu item active, need id in fn call. 		
			//$('li.m-menu__item').removeClass('m-menu__item--active');
			//$(this).parent('li').addClass('m-menu__item--active');
			
		}
		
		// current Dashboard, used when change the role to get de current dashboard and reload it again whith the new role.
		sessionStorage.setItem("currentDashboard", src);
			
		return true;
	}




	// CONTROLLER PUBLIC FUNCTIONS --------------------------------------------------------- 
	return{
		
		// LOAD() JSON LOAD FROM TEMPLATE TO CONTROLLER
		load: function(Data) { 
			logControl ? console.log("\n" + LIB_TITLE + ': load()') : '';			
			return frontReg = Data;
		},		
		
		
		// LANG() CONTROLLER INIT LANGUAGE
		lang: function(lang){
			logControl ? console.log(LIB_TITLE + ': lang()') : '';
			logControl ? console.log('|---> lang() -> assign current Language to Console Menu: ' + lang) : '';
			return currentLanguage = lang;			
		},		
		
		
		// INIT() CONTROLLER INIT CALLS
		init: function(){
			logControl ? console.log("\n" +LIB_TITLE + ': init()') : '';
			
			// SETTING IFRAME CONTROL
				$('iframe').on('load', function(){
					$('#main-dashboard-container').removeClass('m--hide');
					$('.lds-ellipsis').addClass('m--hide');
				});
				
			// MAIN CONFIGURATION
			handleConfiguration(frontReg);			
			
		},	
		
		
		// LOGIN() CONTROLLER LOGIN 
		login: function(){
			logControl ? console.log("\n" +LIB_TITLE + ': login()') : '';
			doLogin();			
		},		
		
		// SESSION FRONTEND CONFIGURATION
		sessionConfiguration: function(){			
			logControl ? console.log("\n" +LIB_TITLE + ': sessionConfiguration()') : '';
			handleSessionConfiguration();
		},

		// SESSION FRONTEND UPDATE AND SAVE CONFIGURATION
		updateConfiguration: function(type){
			logControl ? console.log("\n" +LIB_TITLE + ': updateConfiguration('+ type +')') : '';
			updateSessionConfiguration(type);
			
		},		
		
		// LOAD DASHBOARDS
		loadDashboard: function(src, title, background, height, mode){
			logControl ? console.log("\n" +LIB_TITLE + ': loadDashboard()') : '';
			src ? getDashboard(src, title, background, height, mode) : '';			
		},		
		
		// CLOSE SESSION
		close: function(){
			logControl ? console.log("\n" +LIB_TITLE + ': close()') : '';
			closeSession();	
		},
		
		editMenu: function(item,type){
			logControl ? console.log("\n" +LIB_TITLE + ': handleSessionMenu()') : '';
			handleSessionMenu(item,type);			
		},
		
		roleConfiguration: function(obj){
			logControl ? console.log("\n" +LIB_TITLE + ': roleConfiguration()') : '';
			changeRole(obj);			
		},
		
		roleSelector: function(){
			logControl ? console.log("\n" +LIB_TITLE + ': roleSelector()') : '';
			createRoleSelector();			
		},
		getProject: function(){
			return sessionStorage.getItem("project") || '';			
		},		
		swapDashboard: function(dashboardId){
			logControl ? console.log("\n" +LIB_TITLE + ': swapDashboard()') : '';
			vueapp.dashboard = dashboardId;			
		}
	}
}();

// AUTO INIT CONTROLLER WHEN READY
jQuery(document).ready(function() {
	
	// LOADING JSON DATA FROM THE TEMPLATE (CONF, i18, ...)
	FrontendController.load(mainJson);
	
	// LOADING CURRENT LANGUAGE FROM THE TEMPLATE
	FrontendController.lang(currentLanguage);
	
	// AUTO INIT CONTROLLER.
	FrontendController.init();
	
});