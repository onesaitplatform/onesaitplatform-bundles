Vue.component('vue-global-filters',{
 props: ['activeFilters','entities'],
    data(){
        return {
            frameworks: [],			
			selected: []
        }
    },
	mounted: function(){
		console.log('GLOBAL FILTERS MOUNTED --------------------');
		console.log('ACTIVE FILTERS: ' + this.filters);
		console.log('ENTITIES: ' + this.entities);
	},
    template:`
        <div class="form-group m-form__group row">
			<label class="col-lg-2 col-form-label">seleccionar entidad</label>
			<div class="col-md-3 col-sm-6 col-xs-12">
				<select class="custom-select form-control" id="entities" @change="$emit('sendFilter', selected)"> v-model="selected"  multiple="multiple">
					<option selected="selected">Select Entity</option>
					<option v-for="item in $parent.options" :value="item.codent">{{item.literal}}</option>
				</select>
			</div>
            <label class="col-lg-2 col-form-label">v-model con arrays:</label>
			<div class="col-md-3 col-sm-6 col-xs-12">
				<input type="checkbox" id="vuejs2" value="Vuejs 2" v-model="frameworks" />
				<label for="vuejs2">Vuejs 2</label>

				<input type="checkbox" id="reactjs" value="Reactjs" v-model="frameworks" />
				<label for="reactjs">React js</label>

				<input type="checkbox" id="angular" value="Angular" v-model="frameworks" />
				<label for="angular">Angular</label>

				<p>Frameworks seleccionados: {{frameworks}} </p>
			</div>
        </div>
    `
});